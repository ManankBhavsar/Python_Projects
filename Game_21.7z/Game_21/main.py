import sys


class Game_App:

    def __init__(self):
        while True:
            try:
                self.l1 = []
                self.user = input("Enter 'F' for First chance and 'S' for second chance: ")
                if (self.user == 'F') or (self.user == 'S'):
                    if self.user == "S":
                        self.l1 = [1]
                        print(self.l1)
                    break
            except ValueError:
                continue

    @staticmethod
    def loose():
        print("You loose better luck next time.")
        exit(0)

    def check_num_consecutive(self, num, count):
        if self.user == "S":
            if (self.l1[-1] + 1) == num:
                self.l1.append(num)
                print(self.l1)
            else:
                if count != 0:
                    for j in range(count):
                        self.l1.pop()
                self.user_inputs()
        else:
            if num == 1:
                self.l1.append(num)
            else:
                try:
                    if (self.l1[-1] + 1) == num:
                        self.l1.append(num)
                    else:
                        if count != 0:
                            for j in range(count):
                                self.l1.pop()
                        self.user_inputs()
                except IndexError:
                    print("wrong Value")
                    self.user_inputs()

    def user_inputs(self):
        count = 0
        n = int(input("Enter total numbers to input : "))
        for i in range(n):
            n1 = int(input("Enter your numbers"))
            Game_App.check_num_consecutive(self, n1, count)
            count += 1
            if self.l1[-1] == 21:
                print("Player Won.")
                sys.exit()
            if i == n-1:
                StopIteration()

    def computer_inputs(self):
        if self.l1[-1] not in [4, 8, 12, 16, 20]:
            num1 = (self.l1[-1] % 4)
        else:
            num1 = 1

        for i in range(num1):
            self.l1.append(self.l1[-1] + 1)
        print(self.l1)
        if self.l1[-1] == 21:
            print("Computer Won.")
            sys.exit()


def main():
    obj = Game_App()
    while True:
        obj.user_inputs()
        obj.computer_inputs()


if __name__ == "__main__":
    main()
