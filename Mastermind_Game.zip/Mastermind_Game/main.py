class Mastermind_Game:
    counter = 0
    val1 = 0
    val2 = 0
    num1 = []

    def __init__(self, player_):
        self.player_ = player_

    def set_number(self):
        try:
            Mastermind_Game.val1 = int(input(f"{self.player_} : Enter any two digit number for guess : "))
            num = "x" * 2
            Mastermind_Game.num1 = [i for i in num]
        except ValueError:
            print("Enter integer only")
            self.set_number()

    def check_hint(self):
        if Mastermind_Game.val1 == Mastermind_Game.val2:
            print(f"{self.player_} : You Guessed Right Number.", "\n")
        else:
            for p, q in enumerate(str(Mastermind_Game.val1)):
                for r in str(Mastermind_Game.val2):
                    if q == r:
                        Mastermind_Game.num1[p] = q
            print(Mastermind_Game.num1)

    def player_set_num(self):
        self.set_number()

    @staticmethod
    def win_loose(counter1, counter2):
        if counter1 > counter2:
            print("player2 won")
        elif counter1 < counter2:
            print("player1 won")
        else:
            print("Tie")

    def general_game(self):
        while True:
            try:
                Mastermind_Game.val2 = int(input(f"{self.player_} : Guess any two digit number : "))
            except ValueError:
                self.general_game()
            self.counter += 1
            self.check_hint()
            if Mastermind_Game.val1 == Mastermind_Game.val2:
                break


if __name__ == "__main__":
    obj1 = Mastermind_Game("player_1")
    obj2 = Mastermind_Game("player_2")
    obj1.player_set_num()
    obj2.general_game()
    obj2.player_set_num()
    obj1.general_game()
    x = obj1.counter
    y = obj2.counter
    obj2.win_loose(x, y)
