import requests
from bs4 import BeautifulSoup
import time
from win10toast import ToastNotifier


class Notifier:

    def __init__(self, url):
        self.url = url

    def request_data(self):
        l1 = []
        resp = requests.get(self.url)
        soup = BeautifulSoup(resp.content, 'lxml')

        icon_path_ = "icon.ico"
        n = ToastNotifier()

        while True:
            x = soup.find_all("div", class_="number-table-main")[0].text
            y = soup.find_all("span", class_="number-table")

            for i in y:
                l1.append(i.text)

            message_ = f"Currently infected cases : {x}\
                       Mild Condition : {l1[0]}            \
                       Critical Condition : {l1[1]}"

            n.show_toast("Corona update", message_, duration=30, icon_path=icon_path_)

            min_ = 10
            time.sleep(60*min_)


def main():
    url = "https://www.worldometers.info/coronavirus/country/germany/"
    obj = Notifier(url)
    obj.request_data()


if __name__ == "__main__":
    main()
