class Flame_Game:
    l1 = ["Friends", "Lovers", "Affectionate", "Marriage", "Enemies", "Sibling"]
    n = 0

    def __init__(self):
        self.name1 = [i for i in str.lower(input("Enter first name : ")).strip()]
        self.name2 = [j for j in str.lower(input("Enter second name : ")).strip()]

    def get_len(self):
        counter = 0
        while counter < len(self.name1):
            counter += 1
            for i in self.name1:
                for j in self.name2:
                    if i == j:
                        self.name1.remove(i)
                        self.name2.remove(i)
                        break
                if i == j:
                    break

        Flame_Game.n = len(self.name1) + len(self.name2)

    @staticmethod
    def get_result():
        while len(Flame_Game.l1) > 1:
            cn = Flame_Game.n % len(Flame_Game.l1)
            Flame_Game.l1.pop(cn - 1)
        print(Flame_Game.l1[0])


def main():
    obj = Flame_Game()
    obj.get_len()
    obj.get_result()


if __name__ == "__main__":
    main()
