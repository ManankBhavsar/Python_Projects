import random


class RPS:
    l_temp = ["Rock", "Paper", "Scissor"]
    l1 = ["Rock", "Paper", "Scissor"]
    computer_chance = 0

    def __init__(self):
        print("Choose number From below options :", "\n", "1. Rock", "\n", "2. Paper", "\n", "3. Scissor")
        self.user = int(input("Enter your number : "))

    def computer(self):
        RPS.l1.pop(self.user - 1)
        RPS.computer_chance = random.choice(RPS.l1)

    def play(self):
        if RPS.l_temp[self.user - 1] == "Rock":

            if RPS.computer_chance == "Paper":
                print(f"{RPS.computer_chance}")
                print("Computer Wins")
            else:
                print(f"{RPS.computer_chance}")
                print("Player Wins")

            exit(0)

        elif RPS.l_temp[self.user - 1] == "Paper":

            if RPS.computer_chance == "Scissor":
                print(f"{RPS.computer_chance}")
                print("Computer Wins")
            else:
                print(f"{RPS.computer_chance}")
                print("Player Wins")

            exit(0)

        else:
            if RPS.computer_chance == "Rock":
                print(f"{RPS.computer_chance}")
                print("Computer Wins")
            else:
                print(f"{RPS.computer_chance}")
                print("Player Wins")

            exit(0)


def main():
    try:
        obj = RPS()
    except ValueError:
        print("Enter number only.")
        obj = RPS()

    obj.computer()
    obj.play()


if __name__ == "__main__":
    main()
