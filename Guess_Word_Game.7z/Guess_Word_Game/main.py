import random
from more_itertools import locate


class Word_Guess_App:

    def __init__(self):
        l1 = ["Marcos", "Defence", "Joint", "Operation"]
        self.x = random.choice(l1)
        self.y = len(set(self.x)) + 5

    def user_word(self):
        l3 = list("_"*len(self.x))
        name = input("Enter your Name :")
        print("\n", f"Hello {name}")
        print(f"Guess {len(self.x)} digit word")
        print(f"you have {self.y} chance.", "\n")
        for i in range(self.y):
            print("\n", "".join(l3))
            print(f"You have {self.y - i} chance left.")
            val = str.lower(input("Enter any alphabet : "))
            if val in self.x:
                l2 = list(locate(self.x, lambda a: a == val))
                for j in l2:
                    l3[j] = val
                if sorted(l3) == sorted(self.x):
                    print("\n", "".join(l3))
                    print("Congrats you won.")
                    break
            else:
                continue
        else:
            print(f"The word is {self.x}")
            print("You loose.")


if __name__ == "__main__":
    obj = Word_Guess_App()
    obj.user_word()
